document.getElementById('login-form').addEventListener('submit', async function (event) {
    event.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    const response = await fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
    });
  
    if (response.ok) {
      const data = await response.json();
      if (data.success) {
        window.location.href = '/index';
      } else {
        document.getElementById('login-error').innerText = 'Invalid email or password';
      }
    } else {
      document.getElementById('login-error').innerText = 'Invalid email or password';
    }
  });
  