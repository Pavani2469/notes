document.getElementById('signup-form').addEventListener('submit', async function (event) {
    event.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    const response = await fetch('/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
    });
  
    if (response.ok) {
      const data = await response.json();
      if (data.success) {
        window.location.href = '/login';
      } else {
        document.getElementById('signup-error').innerText = 'Signup failed. Please try again.';
      }
    } else {
      document.getElementById('signup-error').innerText = 'Signup failed. Please try again.';
    }
  });
