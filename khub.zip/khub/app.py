from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import requests

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with your own secret key

API_URL = 'http://localhost:8000'  # Replace with your FastAPI URL

@app.route('/')
def home():
    if 'token' in session:
        return redirect(url_for('index'))
    return redirect(url_for('login_page'))

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/signup')
def signup_page():
    return render_template('signup.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']
    
    response = requests.post(f'{API_URL}/token', data={'email': email, 'password': password})
    
    if response.status_code == 200:
        data = response.json()
        session['token'] = data['access_token']
        return jsonify(success=True)
    else:
        return jsonify(success=False), 401

@app.route('/signup', methods=['POST'])
def signup():
    email = request.form['email']
    password = request.form['password']
    
    response = requests.post(f'{API_URL}/register', data={'email': email, 'password': password})
    
    if response.status_code == 201:
        return jsonify(success=True)
    else:
        return jsonify(success=False), 400

@app.route('/index')
def index():
    if 'token' not in session:
        return redirect(url_for('login_page'))
    return render_template('index.html')

@app.route('/logout')
def logout():
    session.pop('token', None)
    return redirect(url_for('login_page'))

if __name__ == '__main__':
    app.run(debug=True)
    
